import javax.swing.*;

public class PoC {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {}
            JFrame frame = new JFrame("PoC");
            JLabel label = new JLabel("This is a Proof of Concept");

            frame.add(label);
            frame.setSize(300, 200);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}